crayon-lang-ada
===============

some modifications for the crayon syntax highlighter.

Installation:
-------------

1. Search for the folder langs inside your crayon installation
2. Create a folder named ada
3. copy **ALL** txt files into that folder
4. DONE


Aram (crayons creator) has added it to the crayon repo here on github. So you can simply pull the current repo to get it.
https://github.com/aramkocharyan/crayon-syntax-highlighter
