-- MySQL dump 10.16  Distrib 10.1.35-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: phpdarkc_library
-- ------------------------------------------------------
-- Server version	10.1.34-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` varchar(20) NOT NULL,
  `book_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `cover` varchar(100) NOT NULL,
  `isbn` varchar(30) DEFAULT NULL,
  `category` varchar(100) NOT NULL,
  `writer` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `publisher` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `year_of_publish` varchar(10) NOT NULL,
  `version` varchar(100) NOT NULL,
  `self_no` varchar(20) NOT NULL,
  `source` varchar(100) NOT NULL,
  `added_date` date NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'available',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` (`id`, `book_id`, `book_name`, `cover`, `isbn`, `category`, `writer`, `publisher`, `year_of_publish`, `version`, `self_no`, `source`, `added_date`, `status`) VALUES (2,'112','Hajar Bochor Dhore','cover2018-06-12-11-28-45_5b1f5a0dabdf7.jpg','2384BDH9','Novel','Jahir Rayhan','Gankosh Prokashani','1980','4.3.0','4','Buy','2018-06-11','available'),(3,'113','Nakshi Kathar Math','cover2018-06-12-11-28-56_5b1f5a18f0cf0.jpg','23783BB','Novel','Jasim Uddin','Jupitar Prokashani','1992','2.30.2','2','Donation','2018-06-11','available'),(9,'114','Biological Sciences','cover2018-06-12-11-28-34_5b1f5a02d0a29.jpg','1244BSHH','Medical Science','Aristatle','Onnesa Prokashani','1996','19.23.2.0','6','Buys','2018-06-12','available'),(10,'110','Big Bang Theory','cover2018-06-12-16-47-54_5b1fa4dac41bb.jpg','495-347B-23','Fiction','Stefen Hawking','Kotha Prokashani','2001','23.21.20.3','4','International Journal','2018-06-12','borrowed'),(11,'115','Physics I','cover2018-06-12-16-41-19_5b1fa34f4f565.jpg','68845HD','Fiction','Humayon Ahemd','Panjeri Prokashani','2017','2.34.3','3','Buy','2018-06-12','available'),(12,'116','Computer Fundamental','cover2018-06-12-16-48-07_5b1fa4e76f7ea.jpg','78834DJDJ','Fiction','PK Sinha','Gankosh Prokashani','2001','84.32.3','7','International Donation','2018-06-12','available'),(13,'454','ABCDD','cover2018-06-13-09-18-16_5b208cf8f0b14.jpg','5678900','Journal','Jahir Rayhan','Kotha Prokashani','1998','444','5','Donations','2018-06-13','available');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrow`
--

DROP TABLE IF EXISTS `borrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrow` (
  `serial` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` varchar(40) DEFAULT NULL,
  `student_id` varchar(40) DEFAULT NULL,
  `bdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duration` varchar(3) NOT NULL,
  `status` varchar(15) NOT NULL DEFAULT 'borrowed',
  PRIMARY KEY (`serial`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow`
--

LOCK TABLES `borrow` WRITE;
/*!40000 ALTER TABLE `borrow` DISABLE KEYS */;
INSERT INTO `borrow` (`serial`, `book_id`, `student_id`, `bdate`, `rdate`, `duration`, `status`) VALUES (8,'110','3','2018-06-13 18:00:00','2018-06-20 18:00:00','7','borrowed'),(9,'454','1','2018-06-20 18:00:00','2018-06-27 18:00:00','7','borrowed');
/*!40000 ALTER TABLE `borrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `catid` int(11) NOT NULL AUTO_INCREMENT,
  `catname` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`catid`, `catname`) VALUES (1,'Novel'),(2,'Fiction'),(4,'Comic'),(5,'Database Book'),(6,'Journal'),(7,'Poems'),(8,'Medical Science'),(9,'dsfd');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `class`
--

DROP TABLE IF EXISTS `class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class` (
  `classid` int(11) NOT NULL AUTO_INCREMENT,
  `classname` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class`
--

LOCK TABLES `class` WRITE;
/*!40000 ALTER TABLE `class` DISABLE KEYS */;
INSERT INTO `class` (`classid`, `classname`) VALUES (1,'BBA'),(2,'Humanism'),(3,'Mathematics'),(4,'Statistics');
/*!40000 ALTER TABLE `class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `deptid` int(11) NOT NULL AUTO_INCREMENT,
  `deptname` varchar(200) NOT NULL,
  PRIMARY KEY (`deptid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` (`deptid`, `deptname`) VALUES (1,'Computer Science'),(2,'English'),(3,'Bacholor of Business Administration'),(4,'LAW'),(5,'Pharmacy');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publisher`
--

DROP TABLE IF EXISTS `publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publisher` (
  `pubid` int(11) NOT NULL AUTO_INCREMENT,
  `pubname` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`pubid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publisher`
--

LOCK TABLES `publisher` WRITE;
/*!40000 ALTER TABLE `publisher` DISABLE KEYS */;
INSERT INTO `publisher` (`pubid`, `pubname`) VALUES (1,'Kotha Prokashani'),(2,'Onnesa Prokashani'),(3,'Gankosh Prokashani'),(4,'Panjeri Prokashani'),(5,'Jupitar Prokashani');
/*!40000 ALTER TABLE `publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stu_id` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `department` varchar(100) NOT NULL,
  `session` varchar(10) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `class` varchar(100) DEFAULT NULL,
  `section` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` (`id`, `stu_id`, `name`, `department`, `session`, `contact`, `email`, `username`, `password`, `class`, `section`, `status`) VALUES (5,'1','Ariful Islam','Computer Science','2017-2018','01582-MKIDJF','arif@gmail.com','student1','202cb962ac59075b964b07152d234b70','Humanism','B','accepted'),(10,'2','Kawsar Ahmed','Computer Science','2017-2018','019XX-SSHHFF','kawsar@gmail.com','student2','202cb962ac59075b964b07152d234b70','Humanism','C','accepted'),(11,'3','Imdadul Haque','Pharmacy','2012-2013','0185i-HHDDUU','imdad@gmail.com','student3','202cb962ac59075b964b07152d234b70','Mathematics','A','accepted'),(12,'4','Basar Khan','LAW','2017-2018','01758-FFUUDD','basar@hotmail.com','student4','202cb962ac59075b964b07152d234b70','Statistics','B','accepted'),(13,'5','Parvej Hasan','English','2016-2017','01734-JJDDAA','parvej@gmail.com','student5','202cb962ac59075b964b07152d234b70','Mathematics','D','pending');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'stuff',
  `address` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` (`userid`, `username`, `password`, `name`, `email`, `status`, `address`, `logo`) VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3','AVAST','admin@gmail.com','admin','abcd','uploads/logo_.png');
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `writer`
--

DROP TABLE IF EXISTS `writer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `writer` (
  `writerid` int(11) NOT NULL AUTO_INCREMENT,
  `writername` varchar(100) NOT NULL,
  PRIMARY KEY (`writerid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `writer`
--

LOCK TABLES `writer` WRITE;
/*!40000 ALTER TABLE `writer` DISABLE KEYS */;
INSERT INTO `writer` (`writerid`, `writername`) VALUES (1,'Humayon Ahemd'),(4,'Kazi Nazrul Islam'),(5,'Rabindranath Thakur'),(6,'Jasim Uddin'),(7,'Sufia Kamal'),(8,'Stefen Hawking'),(9,'Aristatle'),(10,'Jahir Rayhan'),(11,'PK Sinha');
/*!40000 ALTER TABLE `writer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'phpdarkc_library'
--

--
-- Dumping routines for database 'phpdarkc_library'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-19 18:35:31
