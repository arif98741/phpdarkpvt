-- MySQL dump 10.16  Distrib 10.1.35-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: phpdarkc_ecom
-- ------------------------------------------------------
-- Server version	10.1.34-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL AUTO_INCREMENT,
  `adminName` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adminUser` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adminEmail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adminPass` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`adminId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin`
--

LOCK TABLES `tbl_admin` WRITE;
/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;
INSERT INTO `tbl_admin` (`adminId`, `adminName`, `adminUser`, `adminEmail`, `adminPass`, `level`) VALUES (1,'Shayed ','admin','shayedmollah312@gmail.com','202cb962ac59075b964b07152d234b70',0);
/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_brand`
--

DROP TABLE IF EXISTS `tbl_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_brand` (
  `brandId` int(11) NOT NULL AUTO_INCREMENT,
  `brandName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`brandId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_brand`
--

LOCK TABLES `tbl_brand` WRITE;
/*!40000 ALTER TABLE `tbl_brand` DISABLE KEYS */;
INSERT INTO `tbl_brand` (`brandId`, `brandName`) VALUES (1,'Dhaka'),(2,'Iphone'),(3,'Samsung'),(4,'Acer'),(5,'Canon'),(6,'Canon');
/*!40000 ALTER TABLE `tbl_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_cart`
--

DROP TABLE IF EXISTS `tbl_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cart` (
  `cartId` int(11) NOT NULL AUTO_INCREMENT,
  `sId` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float(10,3) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`cartId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cart`
--

LOCK TABLES `tbl_cart` WRITE;
/*!40000 ALTER TABLE `tbl_cart` DISABLE KEYS */;
INSERT INTO `tbl_cart` (`cartId`, `sId`, `productId`, `productName`, `price`, `quantity`, `image`) VALUES (1,'ii3eailvo4p7alq2c0uhcvqe46',17,'Lorem ipsum dolor sit ',8000.000,1,'upload/33b74b5b78.png');
/*!40000 ALTER TABLE `tbl_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_catagory`
--

DROP TABLE IF EXISTS `tbl_catagory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_catagory` (
  `catId` int(11) NOT NULL AUTO_INCREMENT,
  `catName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`catId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_catagory`
--

LOCK TABLES `tbl_catagory` WRITE;
/*!40000 ALTER TABLE `tbl_catagory` DISABLE KEYS */;
INSERT INTO `tbl_catagory` (`catId`, `catName`) VALUES (1,'Laptop'),(2,'Mobile Phones'),(3,'Dextop'),(4,'Softwer'),(5,'Camera');
/*!40000 ALTER TABLE `tbl_catagory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_compare`
--

DROP TABLE IF EXISTS `tbl_compare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_compare` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float(10,3) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_compare`
--

LOCK TABLES `tbl_compare` WRITE;
/*!40000 ALTER TABLE `tbl_compare` DISABLE KEYS */;
INSERT INTO `tbl_compare` (`id`, `cmrId`, `productId`, `productName`, `price`, `image`) VALUES (1,2,17,'Lorem ipsum dolor sit ',8000.000,'upload/33b74b5b78.png');
/*!40000 ALTER TABLE `tbl_compare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_customar`
--

DROP TABLE IF EXISTS `tbl_customar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_customar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contry` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phpne` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_customar`
--

LOCK TABLES `tbl_customar` WRITE;
/*!40000 ALTER TABLE `tbl_customar` DISABLE KEYS */;
INSERT INTO `tbl_customar` (`id`, `name`, `address`, `city`, `contry`, `zip`, `phpne`, `email`, `pass`) VALUES (2,'Shayed Mollah','West swarapar mirpur dhaka .','Dhaka.','Bangladeshi','1266','+8801755392795','shayedmollah512@gmail.com','202cb962ac59075b964b07152d234b70'),(3,'Arif','Dhaka','Dhaka','Bangladesh','1900','01750840217','arif@gmail.com','e10adc3949ba59abbe56e057f20f883e');
/*!40000 ALTER TABLE `tbl_customar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_list`
--

DROP TABLE IF EXISTS `tbl_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float(10,3) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_list`
--

LOCK TABLES `tbl_list` WRITE;
/*!40000 ALTER TABLE `tbl_list` DISABLE KEYS */;
INSERT INTO `tbl_list` (`id`, `cmrId`, `productId`, `productName`, `price`, `image`) VALUES (2,2,14,'Lorem Ipsum',3000.990,'upload/b94f7f006d.jpg');
/*!40000 ALTER TABLE `tbl_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_order`
--

DROP TABLE IF EXISTS `tbl_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cmrId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` float(10,3) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_order`
--

LOCK TABLES `tbl_order` WRITE;
/*!40000 ALTER TABLE `tbl_order` DISABLE KEYS */;
INSERT INTO `tbl_order` (`id`, `cmrId`, `productId`, `productName`, `quantity`, `price`, `image`, `date`, `status`) VALUES (38,2,17,'Lorem ipsum dolor sit ',1,8000.000,'upload/33b74b5b78.png','2018-07-10 13:35:09',2),(39,2,14,'Lorem Ipsum',1,3000.990,'upload/b94f7f006d.jpg','2018-07-10 13:35:09',0),(41,2,9,'Lorem Ipsum',1,3000.000,'upload/7abd176bdf.png','2018-07-10 13:35:09',2),(42,2,17,'Lorem ipsum dolor sit ',1,8000.000,'upload/33b74b5b78.png','2018-07-10 18:56:43',2),(43,2,17,'Lorem ipsum dolor sit ',1,8000.000,'upload/33b74b5b78.png','2018-07-10 22:49:25',0),(44,2,20,'This is camera ',1,15000.999,'upload/2d367b5025.jpg','2018-07-10 22:49:25',0),(45,3,14,'Lorem Ipsum',1,3000.990,'upload/b94f7f006d.jpg','2018-07-14 01:53:47',0),(46,3,19,'Acer',1,80001.000,'upload/21247ffedf.jpg','2018-07-14 01:53:47',0);
/*!40000 ALTER TABLE `tbl_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_product`
--

DROP TABLE IF EXISTS `tbl_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL AUTO_INCREMENT,
  `productName` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `catId` int(11) NOT NULL,
  `brandId` int(11) NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` float(10,3) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`productId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_product`
--

LOCK TABLES `tbl_product` WRITE;
/*!40000 ALTER TABLE `tbl_product` DISABLE KEYS */;
INSERT INTO `tbl_product` (`productId`, `productName`, `catId`, `brandId`, `body`, `price`, `image`, `type`) VALUES (5,'Lorem Ipsum is simply dummy text ',2,2,'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>',500.000,'upload/29e682756c.png',0),(6,'Lorem Ipsum is simply dummy text',2,3,'<p>Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.</p>',4000.000,'upload/c4563cc263.png',0),(7,'Lorem Ipsum is simply dummy text',3,4,'<p>Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.</p>',40000.000,'upload/7fd7cb14c4.jpg',0),(8,'Lorem Ipsum ',3,4,'<p>Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.</p>',5000.000,'upload/c094d13df3.jpg',1),(9,'Lorem Ipsum',5,5,'<p>Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed dLorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.o eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.</p>',3000.000,'upload/7abd176bdf.png',1),(10,'Lorem Ipsum',4,3,'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>',3000.990,'upload/9b38e4caad.jpg',0),(11,'Lorem Ipsum',2,3,'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>',4000.000,'upload/68f54966a0.jpg',0),(12,'Lorem Ipsum',4,4,'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>',4000.990,'upload/3e45d9e797.jpg',1),(13,'Lorem Ipsum',3,1,'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>',4000.999,'upload/f8cd1e878a.jpg',0),(14,'Lorem Ipsum',4,3,'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore.</p>',3000.990,'upload/b94f7f006d.jpg',0),(17,'Lorem ipsum dolor sit ',2,2,'<p>Lorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmodLorem ipsum dolor sit amet sed do eiusmod</p>',8000.000,'upload/33b74b5b78.png',0),(19,'Acer',3,4,'<p>Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.</p>',80001.000,'upload/21247ffedf.jpg',1),(20,'This is camera ',5,6,'<p>Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.Lorem ipsum dolor sit amet, sed do eiusmod.</p>',15000.999,'upload/2d367b5025.jpg',0);
/*!40000 ALTER TABLE `tbl_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'phpdarkc_ecom'
--

--
-- Dumping routines for database 'phpdarkc_ecom'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-19 18:35:28
