<?php 

	class Helper{
		private $data;

		public function __construct()
		{
			# code...
		}

	}
?>