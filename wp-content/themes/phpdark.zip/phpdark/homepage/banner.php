<section id="banner">
		<div class="container-fluid">
			<div class="banner-data">
				<h1>PHP 7.1.3 Official Beta Released</h1>
				<a href="#">Read More</a>
			</div>
		</div>
	</section>	