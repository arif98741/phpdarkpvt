<?php get_header(); ?>
	
	
	<section id="error">
		<div class="container">
			<div class="error_title">
				<h1>Error 404, Page Not Found</h1>
				
			</div>
			<div class="error_content">
				<p>Page you are trying to access not found or link expired. Please try another page or go to <a href="<?php bloginfo('home'); ?>" style="text-decoration: none; color: blue;">Homepage</a></p>
				
			</div>
		</div>
	</section>

	<section id="mayread">
		<div class="container">
			<div class="blog">
				<h1><!-- You May Read Blog --></h1>
				<div class="blog_title">
					<h1><!-- Blog 1 --></h1>
					<h4></h4>
				</div>
				<div class="blog_content">
					
				</div>
			</div>
		</div>
	</section>
	
		
	<?php  get_footer();?>