<?php get_header(); ?>
		<div class="container-fluid">
			<div id="branding">
				<img src="assets/img/logo.png" alt="" />
				<h1>PHPDark.Com</h1><br/>
				<!-- <span>Your Ultimate PHP Guide</span> -->
			</div>
			<nav>
				<ul>
					<li class="current"><a href="index.html">Home</a></li>
					<li><a href="#">PHP BASIC</a></li>
					<li><a href="#">PHP ADVANCED</a></li>
					<li><a href="#">PROJECT</a></li>
					<li><a href="#">ABOUT US</a></li>
					<li><a href="#">BlOG</a></li>
				</ul>
			</nav>
			<div class="main_search">
				<form action="" method="get">
					<input type="text" placeholder="Enter keywords">
					<input type="submit" class="button_1">
				</form>
			</div>
			
		</div>
	</header>
	
	<section id="page">
		<div class="container">
			<div class="page_title">
				<h1>Privacy Policy</h1>
				<p><i>Published On: 12-December-2017,by Admin</i></p>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, officiis. Aliquam error aut, officiis voluptatum dolorum voluptates reiciendis architecto dolore inventore asperiores exercitationem perferendis itaque consequatur hic obcaecati dolores soluta nemo, modi vitae laborum! Modi cupiditate esse atque dignissimos enim? Fuga nulla quia neque nesciunt, sunt, tempora eius, porro et id facilis nam expedita culpa tempore ad, odit repellat deleniti eos dolorem ex perspiciatis itaque quo! Autem sed esse, molestiae pariatur animi facere nobis quasi expedita beatae. Commodi animi nemo quaerat aliquid aut necessitatibus quo distinctio nobis, aspernatur error, tenetur deserunt minus incidunt eius, a. Eveniet id modi omnis, sit quasi ea cupiditate! Sequi, obcaecati ipsum itaque aliquid eaque unde voluptate aspernatur alias sit hic numquam eum eveniet, porro debitis fugiat. Distinctio quia quae, harum sunt. Nesciunt necessitatibus sequi ipsum sapiente numquam dolorem ex perspiciatis itaque quo! Autem sed esse, molestiae pariatur animi facere nobis quasi expedita beatae. Commodi animi nemo quaerat aliquid aut necessitatibus quo distinctio nobis, aspernatur error, tenetur</p>
				<p>
				deserunt minus incidunt eius, a. Eveniet id modi omnis, sit quasi ea cupiditate! Sequi, obcaecati ipsum itaque aliquid eaque unde voluptate aspernatur alias sit hic numquam eum eveniet, porro debitis fugiat. Distinctio quia quae, harum sunt. Nesciunt necessitatibus sequi ipsum sapiente numquam nulla, nihil praesentium quo eius! Quia, quisquam nisi iure similique odit ducimus sunt magni dolorum quos culpa mollitia inventore, obcaecati excepturi veniam aperiam cupiditate officia atque temporibus veritatis repellendus! Illo impedit harum consequatur unde quidem, alias quia. Nobis voluptatum, autem mollitia rem et accusamus eveniet obcaecati architecto ullam. Nesciunt autem reprehenderit saepe maxime dolorum perferendis optio numquam, sit reiciendis at, quam repudiandae dicta earum harum facere similique, magnam. alias quia. Nobis voluptatum, autem mollitia rem et accusamus eveniet obcaecati architecto ullam. Nesciunt autem reprehenderit saepe maxime dolorum perferendis optio numquam, sit reiciendis at, quam repudiandae dicta earum harum facere similique, magnam.</p>
				<img src="assets/img/1.PNG" class="img img=responsive" alt="">
			</div>
		</div>
	</section>
	
	<?php get_footer(); ?>